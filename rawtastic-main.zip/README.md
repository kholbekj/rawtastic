# Static site ain't getting much easier than this
Eggstatic is a dream of an infectiously simple and fun way to create websites, and inspire others to do the same! Instead of provider lock-in, we generate complete static sites, needing nothing else than a browser, and we unlock other's ability to do the same, directly from our sites!

# Developing
Open the files in some editor.
