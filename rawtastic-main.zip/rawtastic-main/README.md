# Static site ain't getting much easier than this
